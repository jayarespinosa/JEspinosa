function keyDownProcess(e) {
	var keyCode = e.keyCode;


	if (keyCode==13) {
		evaluateEq();
		document.getElementById("buttonequal").style.backgroundColor = "#dddddd";
	}
	else if (keyCode == 48) {
		addNum("0");
		document.getElementById("button0").style.backgroundColor = "#dddddd";
	}
	else if (keyCode == 49) {
		addNum("1");
		document.getElementById("button1").style.backgroundColor = "#dddddd";
	}
	else if (keyCode == 50) {
		addNum("2");
		document.getElementById("button2").style.backgroundColor = "#dddddd";
	}
	else if (keyCode == 51) {
		addNum("3");
		document.getElementById("button3").style.backgroundColor = "#dddddd";
	}
	else if (keyCode == 52) {
		addNum("4");
		document.getElementById("button4").style.backgroundColor = "#dddddd";
	}
	else if (keyCode == 53) {
		addNum("5");
		document.getElementById("button5").style.backgroundColor = "#dddddd";
	}
	else if (keyCode == 54) {
		addNum("6");
		document.getElementById("button6").style.backgroundColor = "#dddddd";
	}
	else if (keyCode == 55) {
		addNum("7");
		document.getElementById("button7").style.backgroundColor = "#dddddd";
	}
	else if (e.shiftKey) {
		if (keyCode == 56) {
			process("multiply");
			document.getElementById("buttonmultiply").style.backgroundColor = "#9dd2ea";
		}
	}
	else if (keyCode == 56) {
		addNum("8");
		document.getElementById("button8").style.backgroundColor = "#dddddd";
	}
	else if (keyCode == 57) {
		addNum("9");
		document.getElementById("button9").style.backgroundColor = "#dddddd";
	}
	else if (keyCode == 190) {
		addNum(".");
		document.getElementById("buttondecimal").style.backgroundColor = "#dddddd";
	}
	else if (keyCode == 8) {
		addNum("BS");
		document.getElementById("buttonBS").style.backgroundColor = "#ff9fa8";
	}
	else if (keyCode == 67) {
		addNum("CA");
		document.getElementById("buttonCA").style.backgroundColor = "#ff9fa8";
	}
	else if (keyCode == 187) {
		process("add");
		document.getElementById("buttonadd").style.backgroundColor = "#9dd2ea";
	}
	else if (keyCode == 189) {
		process("subtract");
		document.getElementById("buttonsubtract").style.backgroundColor = "#9dd2ea";
	}
	else if (keyCode == 191) {
		process("divide");
		document.getElementById("buttondivide").style.backgroundColor = "#9dd2ea";
	}
}

function keyupProcess(e) {
	var keyCode = e.keyCode;
	if (keyCode==13) {
		evaluateEq();
		document.getElementById("buttonequal").style.backgroundColor = "#ffffff";
	}
	else if (keyCode == 48) {
		document.getElementById("button0").style.backgroundColor = "#ffffff";
	}
	else if (keyCode == 49) {
		document.getElementById("button1").style.backgroundColor = "#ffffff";
	}
	else if (keyCode == 50) {
		document.getElementById("button2").style.backgroundColor = "#ffffff";
	}
	else if (keyCode == 51) {
		
		document.getElementById("button3").style.backgroundColor = "#ffffff";
	}
	else if (keyCode == 52) {
		document.getElementById("button4").style.backgroundColor = "#ffffff";
	}
	else if (keyCode == 53) {
		document.getElementById("button5").style.backgroundColor = "#ffffff";
	}
	else if (keyCode == 54) {
		document.getElementById("button6").style.backgroundColor = "#ffffff";
	}
	else if (keyCode == 55) {
		document.getElementById("button7").style.backgroundColor = "#ffffff";
	}
	else if (keyCode == 56) {
		document.getElementById("button8").style.backgroundColor = "#ffffff";
		document.getElementById("buttonmultiply").style.backgroundColor = "#ffffff";
	}
	else if (keyCode == 57) {

		document.getElementById("button9").style.backgroundColor = "#ffffff";
	}
	else if (keyCode == 190) {
		document.getElementById("buttondecimal").style.backgroundColor = "#ffffff";
	}
	else if (keyCode == 8) {
		document.getElementById("buttonBS").style.backgroundColor = "#ffffff";
	}
	else if (keyCode == 67) {
		document.getElementById("buttonCA").style.backgroundColor = "#ffffff";
	}
	else if (keyCode == 187) {
		document.getElementById("buttonadd").style.backgroundColor = "#ffffff";
	}
	else if (keyCode == 189) {
		document.getElementById("buttonsubtract").style.backgroundColor = "#ffffff";
	}
	else if (keyCode == 191) {
		document.getElementById("buttondivide").style.backgroundColor = "#ffffff";
	}
}

document.addEventListener("keydown", keyDownProcess, false);
document.addEventListener("keyup", keyupProcess, false);




function addNum(num) {
	var result = document.getElementById("result");
	var equation = document.getElementById("equation");

	if (result.innerHTML != "") {
		equation.innerHTML = "";
		result.innerHTML = "";
	}

	if (num == "M-") {
		document.getElementById("forMemory").innerHTML = "M: ";
	}
	else if (num == "CA") {
		result.innerHTML = "";
		equation.innerHTML = "";
	}
	else if (num == "BS") {
		equation.innerHTML = equation.innerHTML.slice(0, -1);
	}
	else {
		equation.innerHTML += num;
	}
	
}

function evaluateEq() {
	var result = document.getElementById("result");
	var equation = document.getElementById("equation");
	var equationVal = document.getElementById("equation").innerHTML;

	equation.innerHTML += result.innerHTML;
	try {
		var answer = eval(equation.innerHTML)
		result.innerHTML = answer;
	}
	catch(err) {
		alert("Syntax error");
		result.innerHTML = "";
		equation.innerHTML = "";
	}
	
}

function process(operation) {
	var result = document.getElementById("result");
	var equation = document.getElementById("equation");
	var equationVal = document.getElementById("equation").value;


	if (result.innerHTML != "") {
		equation.innerHTML = "";
		result.innerHTML = "";
	}

	if (operation == "add") {
		equation.innerHTML += "+";

	}
	else if (operation == "subtract") {
		equation.innerHTML += "-";

	}

	else if (operation == "multiply") {
		equation.innerHTML += "*";

	}

	else if (operation == "divide") {
		equation.innerHTML += "/";

	}

}

function memory() {
	var result = document.getElementById("result").innerHTML;
	if (result != "") {
		document.getElementById("forMemory").innerHTML = "M: " + result;
	}
	else {
		alert("No value to be stored.");
	}
}